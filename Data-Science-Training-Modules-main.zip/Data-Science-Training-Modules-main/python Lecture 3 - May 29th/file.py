#this is a file with a single instruction and a comment
print("hello")